(() => {
  "use strict";
  const KEY = "pp_inline_improve_enabled";
  const selectors = ({
    "chatgpt.com": ["#prompt-textarea", "[data-testid='composer'] [contenteditable='true']", "main form [contenteditable='true']"],
    "chat.openai.com": ["#prompt-textarea", "[data-testid='composer'] [contenteditable='true']"],
    "claude.ai": ["[data-testid='chat-input'] [contenteditable='true']", ".ProseMirror[contenteditable='true']"],
    "gemini.google.com": ["rich-textarea .ql-editor[contenteditable='true']", "rich-textarea [contenteditable='true']"]
  })[location.hostname];
  if (!selectors || !globalThis.chrome?.runtime?.id || !chrome.storage?.local) return;
  let enabled = false, input = null, busy = false, snapshot = null, scheduled = false;
  const host = document.createElement("div");
  host.id = "ttalkak-inline-root";
  host.style.cssText = "position:fixed;inset:0;width:0;height:0;z-index:2147483646;pointer-events:none";
  const shadow = host.attachShadow({ mode: "closed" });
  const style = document.createElement("style");
  style.textContent = [
    "*,*:before,*:after{box-sizing:border-box}button{font:inherit;cursor:pointer}",
    "#tt-button{display:none;position:fixed;pointer-events:auto;padding:7px 11px;border:1px solid #cbd5e1;border-radius:9px;background:#fff;color:#1e293b;box-shadow:0 3px 12px #0002;font:600 12px/1.4 system-ui,sans-serif}",
    "#tt-button:disabled{opacity:.6;cursor:wait}",
    "#tt-panel{display:none;position:fixed;pointer-events:auto;width:min(420px,calc(100vw - 24px));max-height:50vh;overflow:auto;padding:14px;border:1px solid #cbd5e1;border-radius:12px;background:#fff;color:#1e293b;box-shadow:0 12px 30px #0003;font:13px/1.6 system-ui,sans-serif}",
    ".tt-title,.tt-change{color:#2563eb}.tt-title{font-weight:700;margin:0 0 8px}.tt-change{font-weight:600}",
    "#tt-text{white-space:pre-wrap;overflow-wrap:anywhere;max-height:180px;overflow-y:auto}",
    "#tt-message{white-space:pre-line;font-size:12px;color:#64748b;margin:5px 0}",
    "#tt-answer{display:block;width:100%;margin:8px 0;padding:6px;font:inherit;color:inherit;background:transparent;border:1px solid #94a3b8;border-radius:5px}#tt-submit{font:inherit;padding:4px 9px}",
    ".tt-actions{display:flex;justify-content:flex-end;flex-wrap:wrap;gap:8px;margin-top:12px}",
    ".tt-actions button{padding:7px 10px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#1e293b;font-size:12px}",
    "#tt-apply{background:#111827;color:white;border-color:#111827}",
    ".tt-actions button:disabled{opacity:.5;cursor:not-allowed}",
    "button:focus-visible{outline:2px solid #2563eb;outline-offset:2px}",
    "[hidden]{display:none!important}",
    "@media(prefers-color-scheme:dark){#tt-panel,#tt-button{background:#202123;color:#f3f4f6;border-color:#4b5563}.tt-actions button{background:#292b2f;color:#f3f4f6;border-color:#4b5563}#tt-apply{background:#e5e7eb;color:#111827}}"
  ].join("");
  function button(id, text) {
    const el = document.createElement("button");
    el.id = id;
    el.type = "button";
    el.textContent = text;
    return el;
  }
  const trigger = button("tt-button", "✨ 딸깍 개선");
  const panel = document.createElement("section");
  panel.id = "tt-panel";
  panel.setAttribute("aria-label", "딸깍 개선 미리보기");
  const title = document.createElement("div");
  title.className = "tt-title";
  title.textContent = "✨ 개선된 프롬프트";
  const message = document.createElement("div");
  message.id = "tt-message";
  const text = document.createElement("div");
  text.id = "tt-text";
  const fields = document.createElement("fieldset");
  fields.hidden = true;
  const actions = document.createElement("div");
  actions.className = "tt-actions";
  const close = button("tt-close", "닫기");
  const apply = button("tt-apply", "개선 적용");
  const restore = button("tt-restore", "원본 복원");
  restore.hidden = true;
  actions.append(close, restore, apply);
  const followup = document.createElement("div");
  followup.hidden = true;
  const answer = document.createElement("textarea");
  answer.id = "tt-answer";
  answer.rows = 2;
  answer.maxLength = 12000;
  answer.placeholder = "추가 질문에 답해 주세요";
  answer.setAttribute("aria-label", "추가 질문 답변");
  const submit = button("tt-submit", "답변으로 개선");
  followup.append(answer, submit);
  panel.append(title, message, text, fields, followup, actions);
  shadow.append(style, trigger, panel);
  const getText = (el) => el?.matches?.("textarea,input") ? el.value : (el?.innerText ?? el?.textContent ?? "");
  // Rich-text editors render paragraph breaks differently from plain text. Only
  // normalize those presentation differences for post-insertion verification.
  function sameRenderedText(actual, expected) {
    const normalize = (value) => String(value ?? "")
      .replace(/\r\n?/g, "\n")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]*\n[ \t]*/g, "\n")
      .replace(/\n{2,}/g, "\n")
      .trim();
    return actual === expected || normalize(actual) === normalize(expected);
  }
  function visible(el) {
    if (!el?.isConnected) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 100 && r.height > 16 && s.display !== "none" && s.visibility !== "hidden";
  }
  function target() {
    for (const selector of selectors) {
      const el = Array.from(document.querySelectorAll(selector)).find(visible);
      if (el) return el;
    }
    return null;
  }
  function position() {
    if (!input) return;
    const r = input.getBoundingClientRect(), w = Math.min(420, innerWidth - 24);
    const bTop = r.bottom + 43 < innerHeight ? r.bottom + 5 : Math.max(8, r.top - 35);
    trigger.style.top = Math.round(bTop) + "px";
    trigger.style.left = Math.round(Math.max(12, Math.min(innerWidth - 140, r.right - 140))) + "px";
    panel.style.left = Math.round(Math.max(12, Math.min(innerWidth - w - 12, r.right - w))) + "px";
    panel.style.top = Math.round(bTop + 225 < innerHeight ? bTop + 43 : Math.max(8, r.top - Math.min(245, innerHeight / 2))) + "px";
  }
  function dismiss() { snapshot = null; fields.hidden = true; followup.hidden = true; answer.value = ""; panel.style.display = "none"; message.textContent = ""; }
  function refresh() {
    scheduled = false;
    if (!enabled || !document.body) return;
    if (!host.isConnected) document.body.append(host);
    const found = target();
    if (found !== input) { input = found; dismiss(); }
    trigger.style.display = input ? "block" : "none";
    position();
  }
  function schedule() {
    if (enabled && !scheduled) { scheduled = true; requestAnimationFrame(refresh); }
  }
  function toggle(on) {
    enabled = on === true;
    if (!enabled) {
      input = null; dismiss(); trigger.style.display = "none"; host.remove();
    } else schedule();
  }
  function keyPhraseRanges(original, improved) {
    // Prefer the most substantive new sentence, not every word missing from the original.
    // This is a conservative UI heuristic, not an AI-generated semantic diff.
    const originalWords = new Set((original.match(/[\p{L}\p{N}_]+/gu) || []).map((word) => word.toLowerCase()));
    const filler = new Set(["주세요", "해주세요", "해", "그리고", "또한", "먼저", "다음", "대한", "대해", "있다면", "please", "the", "and", "with", "that", "this"]);
    const sentences = Array.from(improved.matchAll(/[^.!?\n]+/gu), (match) => {
      const tokens = match[0].match(/[\p{L}\p{N}_]+/gu) || [];
      const score = tokens.reduce((sum, word) => {
        const lower = word.toLowerCase();
        return sum + (!originalWords.has(lower) && !filler.has(lower) ? Math.min(word.length, 10) : 0);
      }, 0);
      return { start: match.index, body: match[0], score };
    }).sort((a, b) => b.score - a.score);
    const best = sentences[0];
    if (!best || best.score < 8) return [];

    const connectors = /(?:고려하여|바탕으로|기준으로|포함하여|반영하여|활용하여|참고하여|중심으로|위주로|통해|고려해|포함해|반영해|활용해)\s+/gu;
    const parts = [];
    let start = 0;
    for (const match of best.body.matchAll(connectors)) {
      const end = match.index + match[0].length;
      if (end - start < 10) continue;
      parts.push({ start, end });
      start = end;
    }
    parts.push({ start, end: best.body.length });
    const ranges = [];
    for (const part of parts) {
      let left = part.start, right = part.end;
      while (left < right && /\s/u.test(best.body[left])) left++;
      while (right > left && /\s/u.test(best.body[right - 1])) right--;
      // The request ending is not itself a changed requirement.
      const candidate = best.body.slice(left, right);
      const requestEnding = candidate.match(/\s+(?:정리해|작성해|제시해|설명해|추천해|제공해|말해|알려|답변해|구성해|생성해|보여)?\s*주세요\s*$/u);
      if (requestEnding) right -= requestEnding[0].length;
      if (right - left > 38) {
        const prefix = best.body.slice(left, left + 39);
        const boundary = prefix.lastIndexOf(" ");
        right = left + (boundary >= 14 ? boundary : 38);
      }
      const phrase = best.body.slice(left, right);
      const words = phrase.match(/[\p{L}\p{N}_]+/gu) || [];
      const novelty = words.filter((word) => !originalWords.has(word.toLowerCase()) && !filler.has(word.toLowerCase()));
      if (novelty.length < 2 || phrase.length < 8) continue;
      ranges.push({ start: best.start + left, end: best.start + right, score: novelty.reduce((sum, word) => sum + word.length, 0) });
    }
    // Maximum two cohesive, useful phrases; never color the entire response.
    return ranges.sort((a, b) => b.score - a.score).slice(0, 2).sort((a, b) => a.start - b.start);
  }
  function preview(original, improved) {
    text.replaceChildren();
    if (!improved) return;
    let cursor = 0;
    for (const range of keyPhraseRanges(original, improved)) {
      text.append(document.createTextNode(improved.slice(cursor, range.start)));
      const mark = document.createElement("span");
      mark.className = "tt-change";
      mark.textContent = improved.slice(range.start, range.end);
      text.append(mark);
      cursor = range.end;
    }
    text.append(document.createTextNode(improved.slice(cursor)));
  }
  function showFields(turn, template, extraNames) {
    fields.replaceChildren();
    fields.disabled = false;
    const pattern = /\[([^\]\n]{1,80})\]/g;
    const slots = Array.from(template.matchAll(pattern), match => match[1]);
    const names = new Set([...slots, ...extraNames]);
    fields.hidden = !template || !names.size;
    if (fields.hidden) return;
    const controls = new Map();
    const legend = document.createElement("legend");
    legend.textContent = "채워 넣을 정보";
    fields.append(legend);
    for (const name of names) {
      const label = document.createElement("label");
      label.style.display = "block";
      const control = document.createElement("input");
      controls.set(name, control);
      label.append(name, control);
      fields.append(label);
    }
    fields.oninput = () => {
      const value = name => controls.get(name).value.trim();
      const filled = template.replace(pattern, (token, name) => value(name) || token);
      const additions = [...names].filter(name => !slots.includes(name) && value(name));
      turn.improved = [filled, ...additions.map(name => `${name}: ${value(name)}`)].join("\n");
      preview(turn.original, turn.improved);
    };
  }
  function writeValue(el, value) {
    if (!el?.isConnected) return false;
    el.focus();
    if (el.matches("textarea,input")) {
      const proto = el.matches("textarea") ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(el, value); else el.value = value;
      el.dispatchEvent(new Event("input", { bubbles:true }));
      el.dispatchEvent(new Event("change", { bubbles:true }));
    } else if (el.isContentEditable) {
      const selection = getSelection(), range = document.createRange();
      range.selectNodeContents(el);
      selection.removeAllRanges(); selection.addRange(range);
      // Let the host editor (ChatGPT/ProseMirror, Claude, Gemini) process the
      // browser's trusted edit transaction. Direct replaceChildren() mutates the
      // DOM without an editor transaction and can leave the input half-changed.
      if (!document.execCommand("insertText", false, value)) return false;
    } else return false;
    return sameRenderedText(getText(el), value);
  }
  trigger.addEventListener("click", () => {
    if (!enabled || busy || !input) return;
    const source = input, original = getText(source);
    if (!original.trim() || original.length > 12000) {
      dismiss(); panel.style.display = "block";
      title.textContent = "입력 확인";
      text.textContent = !original.trim() ? "개선할 문장을 먼저 작성해 주세요." : "12,000자 이내로 입력해 주세요.";
      apply.hidden = true; restore.hidden = true; position(); return;
    }
    dismiss();
    snapshot = { source, original, improved: "", applied: false };
    requestTurn(original);
  });
  function requestTurn(prompt) {
    const turn = snapshot;
    const { source, original, continuation } = turn;
    if (turn.lastPrompt !== prompt) {
      turn.requestId = crypto.randomUUID();
      turn.lastPrompt = prompt;
    }
    busy = true;
    trigger.disabled = submit.disabled = answer.disabled = apply.disabled = true;
    trigger.textContent = "개선 중…";
    chrome.runtime.sendMessage({ type:"INLINE_IMPROVE", prompt, continuation, requestId: turn.requestId }, (reply) => {
      busy = false; trigger.disabled = answer.disabled = false; trigger.textContent = "✨ 딸깍 개선";
      if (snapshot !== turn || !enabled || !source.isConnected || source !== input) return;
      const error = chrome.runtime.lastError?.message || reply?.error || (!reply && "응답을 받지 못했습니다.");
      if (error && continuation) {
        message.textContent = turn.notice + "\n" + String(error);
        submit.disabled = false;
        apply.disabled = getText(source) !== original;
        return;
      }
      const candidate = error ? "" : String(reply?.improvedPrompt || "").trim();
      const unchanged = candidate.replace(/\s+/g, " ").trim() === original.replace(/\s+/g, " ").trim();
      const improved = unchanged || sameRenderedText(candidate, prompt) ? "" : candidate;
      turn.improved = improved;
      turn.continuation = reply?.continuation;
      turn.lastPrompt = null;
      answer.value = "";
      submit.disabled = true;
      preview(original, improved);
      showFields(turn, improved, reply?.missingFieldNames || []);
      const changed = getText(source) !== original;
      const questions = reply?.questions || [];
      const needsAnswer = reply?.mode === "ask";
      title.textContent = improved ? "✨ 개선된 프롬프트" : needsAnswer ? "추가 질문" : "개선 결과";
      const notices = [];
      if (error) {
        notices.push(String(error));
      } else {
        if (reply?.ragStatus === "no_evidence") {
          notices.push(improved ? "참고 근거 없이 기본 방식으로 다듬었습니다." :
            reply.explanation || "관련 프롬프트 기법 근거를 찾지 못했습니다.");
        } else if (!improved && !questions.length) {
          notices.push(needsAnswer ? reply.explanation || "추가 정보가 필요합니다." : "적용할 변경 사항이 없습니다.");
        }
        if (questions.length) {
          notices.push(needsAnswer ? "아래 질문에 답해 주세요." : "추가 질문 (선택)");
          notices.push(...questions.map((question, index) => (index + 1) + ". " + question));
        }
        if (improved && changed) notices.push("입력 내용이 변경되어 적용할 수 없습니다. 다시 개선해 주세요.");
      }
      turn.notice = notices.join("\n");
      message.textContent = turn.notice;
      followup.hidden = !!error || !(questions.length || needsAnswer) || !turn.continuation;
      turn.canAnswer = !followup.hidden;
      apply.hidden = !improved; apply.disabled = changed; restore.hidden = true;
      panel.style.display = "block"; position();
    });
  }
  answer.addEventListener("input", () => { submit.disabled = busy || !answer.value.trim(); });
  // Keep keystrokes inside the extension from triggering host-page shortcuts.
  for (const event of ["keydown", "keyup", "keypress"]) {
    answer.addEventListener(event, (e) => e.stopPropagation());
    fields.addEventListener(event, (e) => e.stopPropagation());
  }
  submit.addEventListener("click", () => {
    if (busy || !snapshot || !answer.value.trim()) return;
    if (getText(snapshot.source) !== snapshot.original) {
      message.textContent = "입력 내용이 변경되었습니다. 원문에서 다시 개선해 주세요.";
      return;
    }
    requestTurn(answer.value.trim());
  });
  apply.addEventListener("click", () => {
    if (!snapshot || snapshot.applied || !snapshot.improved) return;
    if (getText(snapshot.source) !== snapshot.original) {
      message.textContent = "작성 중인 문장을 보호하기 위해 적용하지 않았습니다."; apply.disabled = true; return;
    }
    if (!writeValue(snapshot.source, snapshot.improved)) {
      // Preserve the user's input and avoid unsafe follow-up overwrite.
      apply.disabled = getText(snapshot.source) !== snapshot.original;
      message.textContent = "입력창 교체에 실패했습니다.";
      return;
    }
    fields.disabled = true; snapshot.applied = true; followup.hidden = true; apply.hidden = true; restore.hidden = false;
    message.textContent = "개선 적용 완료 · AI 전송은 직접 해 주세요.";
  });
  restore.addEventListener("click", () => {
    if (!snapshot?.applied) return;
    if (!sameRenderedText(getText(snapshot.source), snapshot.improved)) {
      message.textContent = "적용 후 수정된 문장은 덮어쓰지 않습니다."; return;
    }
    if (!writeValue(snapshot.source, snapshot.original)) {
      message.textContent = "원본 복원에 실패했습니다."; return;
    }
    fields.disabled = false; snapshot.applied = false; followup.hidden = !snapshot.canAnswer; apply.hidden = false; apply.disabled = false; restore.hidden = true;
    message.textContent = "원본 프롬프트를 복원했습니다.";
  });
  close.addEventListener("click", dismiss);
  chrome.storage.local.get([KEY], (result) => { if (!chrome.runtime.lastError) toggle(result?.[KEY]); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[KEY]) toggle(changes[KEY].newValue);
  });
  new MutationObserver(schedule).observe(document.documentElement, { childList:true, subtree:true });
  addEventListener("resize", schedule, { passive:true });
  addEventListener("scroll", schedule, { passive:true, capture:true });
})();