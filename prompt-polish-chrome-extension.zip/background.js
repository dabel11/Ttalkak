chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "EXECUTE_PROMPT") return false;

  findTargetTab(message.target, async (tab) => {
    if (!tab?.id || !message.prompt) {
      sendResponse({ ok: false, error: "No supported active tab or prompt." });
      return;
    }

    try {
      if (isClaudePage(tab.url)) {
        sendResponse({ ok: false, fallback: "clipboard", error: "Claude uses clipboard fallback." });
        return;
      }

      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: focusPromptInput,
      });

      await sleep(120);

      if (isChatGptPage(tab.url)) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: insertPromptIntoChatGpt,
          args: [message.prompt],
        });
      } else if (isGeminiPage(tab.url)) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: insertPromptIntoGemini,
          args: [message.prompt],
        });
      } else {
        try {
          await insertTextWithDebugger(tab.id, message.prompt);
        } catch (_debuggerError) {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: insertPromptIntoPage,
            args: [message.prompt],
          });
        }
      }

      sendResponse({ ok: true });
    } catch (error) {
      sendResponse({ ok: false, error: String(error) });
    }
  });

  return true;
});

async function findTargetTab(targetName = "auto", callback) {
  const activeTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const activeTab = activeTabs[0];

  if (targetName === "chatgpt") {
    const chatGptTabs = await chrome.tabs.query({
      url: ["https://chatgpt.com/*", "https://chat.openai.com/*"],
    });
    callback(preferActiveTab(activeTab, chatGptTabs, isChatGptPage));
    return;
  }

  if (targetName === "gemini") {
    const geminiTabs = await chrome.tabs.query({
      url: ["https://gemini.google.com/*"],
    });
    callback(preferActiveTab(activeTab, geminiTabs, isGeminiPage));
    return;
  }

  if (targetName === "auto" && isSupportedAiPage(activeTab?.url)) {
    callback(activeTab);
    return;
  }

  callback(undefined);
}

function preferActiveTab(activeTab, tabs, matcher) {
  if (matcher(activeTab?.url)) return activeTab;
  return tabs[0];
}

function isSupportedAiPage(url = "") {
  return (
    url.startsWith("https://chatgpt.com/") ||
    url.startsWith("https://chat.openai.com/") ||
    url.startsWith("https://claude.ai/") ||
    url.startsWith("https://gemini.google.com/")
  );
}

function isClaudePage(url = "") {
  return url.startsWith("https://claude.ai/");
}

function isChatGptPage(url = "") {
  return url.startsWith("https://chatgpt.com/") || url.startsWith("https://chat.openai.com/");
}

function isGeminiPage(url = "") {
  return url.startsWith("https://gemini.google.com/");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function insertTextWithDebugger(tabId, text) {
  const target = { tabId };
  await chrome.debugger.attach(target, "1.3");
  try {
    await chrome.debugger.sendCommand(target, "Input.insertText", { text });
  } finally {
    await chrome.debugger.detach(target);
  }
}

function focusPromptInput() {
  const target =
    document.querySelector("#prompt-textarea") ||
    document.querySelector("textarea") ||
    document.querySelector("div.ProseMirror[contenteditable]") ||
    document.querySelector("[contenteditable]") ||
    document.querySelector("[role='textbox']");

  if (!target) {
    throw new Error("Prompt input not found.");
  }

  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  target.focus();
}

function insertPromptIntoChatGpt(prompt) {
  function setValue(element, value) {
    const proto = element.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
  }

  const target =
    document.querySelector("#prompt-textarea") ||
    document.querySelector("main form [contenteditable='true']") ||
    document.querySelector("textarea");

  if (!target) {
    throw new Error("ChatGPT prompt input not found.");
  }

  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  target.focus();

  if (target.tagName === "TEXTAREA" || target.tagName === "INPUT") {
    setValue(target, prompt);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return;
  }

  target.innerHTML = "";
  const lines = prompt.split("\n");
  for (const line of lines) {
    const paragraph = document.createElement("p");
    paragraph.textContent = line || "\u00a0";
    target.appendChild(paragraph);
  }

  target.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      composed: true,
      inputType: "insertText",
      data: prompt,
    }),
  );
  target.dispatchEvent(new Event("change", { bubbles: true }));

  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(target);
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);
}

function insertPromptIntoGemini(prompt) {
  const candidates = [
    "rich-textarea div.ql-editor[contenteditable='true']",
    "rich-textarea [contenteditable='true']",
    "div.ql-editor[contenteditable='true']",
    "[aria-label*='Enter a prompt' i]",
    "[aria-label*='prompt' i]",
    "[contenteditable='true']",
    "textarea",
  ];

  const target = candidates
    .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
    .find((element) => {
      const rect = element.getBoundingClientRect?.();
      if (!rect || rect.width < 20 || rect.height < 10) return false;
      const style = window.getComputedStyle(element);
      return style.display !== "none" && style.visibility !== "hidden";
    });

  if (!target) {
    throw new Error("Gemini prompt input not found.");
  }

  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  target.focus();

  if (target.tagName === "TEXTAREA" || target.tagName === "INPUT") {
    const proto = target.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(target, prompt);
    else target.value = prompt;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return;
  }

  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(target);
  range.collapse(false);
  selection.removeAllRanges();
  selection.addRange(range);

  const inserted = document.execCommand("insertText", false, prompt);

  if (!inserted || !target.textContent?.includes(prompt.slice(0, 20))) {
    target.innerHTML = "";
    for (const line of prompt.split("\n")) {
      const paragraph = document.createElement("p");
      paragraph.textContent = line || "\u00a0";
      target.appendChild(paragraph);
    }
  }

  target.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      composed: true,
      inputType: "insertText",
      data: prompt,
    }),
  );
  target.dispatchEvent(new Event("change", { bubbles: true }));
}

function insertPromptIntoPage(prompt) {
  function isEditable(element) {
    if (!element) return false;
    const tag = element.tagName;
    return (
      tag === "TEXTAREA" ||
      tag === "INPUT" ||
      element.hasAttribute("contenteditable") ||
      element.getAttribute("role") === "textbox"
    );
  }

  function isVisibleEditable(element) {
    const rect = element.getBoundingClientRect?.();
    if (!rect || rect.width < 20 || rect.height < 10) return false;
    const style = window.getComputedStyle(element);
    return style.display !== "none" && style.visibility !== "hidden";
  }

  function findInput() {
    const selectors = [
      "#prompt-textarea",
      "textarea[placeholder]",
      "textarea",
      "[data-testid='chat-input'] [contenteditable]",
      "[data-testid='chat-input']",
      "[data-testid='composer'] [contenteditable]",
      "[data-testid='composer']",
      "[aria-label*='Message' i]",
      "[aria-label*='prompt' i]",
      "[aria-label*='message' i]",
      "[placeholder*='Message' i]",
      "div.ProseMirror[contenteditable]",
      "[contenteditable='plaintext-only']",
      "[contenteditable='true']",
      "[contenteditable]",
      "[role='textbox']",
    ];

    const candidates = selectors
      .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
      .flatMap((element) => {
        if (isEditable(element)) return [element];
        return Array.from(
          element.querySelectorAll?.("textarea, input, [contenteditable], [role='textbox']") || [],
        );
      })
      .filter(isVisibleEditable);

    candidates.sort((a, b) => {
      const ar = a.getBoundingClientRect();
      const br = b.getBoundingClientRect();
      return br.bottom - ar.bottom || br.width * br.height - ar.width * ar.height;
    });

    return candidates[0];
  }

  function setValue(element, value) {
    const proto = element.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
  }

  function pasteEvent(target, text) {
    try {
      const data = new DataTransfer();
      data.setData("text/plain", text);
      const event = new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        composed: true,
        clipboardData: data,
      });
      target.dispatchEvent(event);
      return target.textContent?.includes(text.slice(0, 20));
    } catch (_error) {
      return false;
    }
  }

  function execInsert(target, text) {
    try {
      const range = document.createRange();
      range.selectNodeContents(target);
      range.collapse(false);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      const inserted = document.execCommand("insertText", false, text);
      target.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: text }));
      return inserted && target.textContent?.includes(text.slice(0, 20));
    } catch (_error) {
      return false;
    }
  }

  const target = findInput();

  if (!target) {
    throw new Error("Prompt input not found.");
  }

  target.scrollIntoView({ block: "center", inline: "nearest" });
  target.click();
  target.focus();

  if (target.tagName === "TEXTAREA" || target.tagName === "INPUT") {
    setValue(target, prompt);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return;
  }

  if (pasteEvent(target, prompt)) return;
  if (execInsert(target, prompt)) return;

  target.innerHTML = "";
  for (const line of prompt.split("\n")) {
    const paragraph = document.createElement("p");
    paragraph.textContent = line || "\u00a0";
    target.appendChild(paragraph);
  }
  target.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: prompt }));
  target.dispatchEvent(new Event("change", { bubbles: true }));
}

function findBestPromptInput() {
  const selectors = [
    "#prompt-textarea",
    "textarea[placeholder]",
    "textarea",
    "[data-testid='chat-input'] [contenteditable]",
    "[data-testid='chat-input']",
    "[data-testid='composer'] [contenteditable]",
    "[data-testid='composer']",
    "[aria-label*='Message' i]",
    "[aria-label*='prompt' i]",
    "[aria-label*='message' i]",
    "[placeholder*='Message' i]",
    "div.ProseMirror[contenteditable]",
    "[contenteditable='plaintext-only']",
    "[contenteditable='true']",
    "[contenteditable]",
    "[role='textbox']",
  ];

  const candidates = selectors
    .flatMap((selector) => Array.from(document.querySelectorAll(selector)))
    .flatMap((element) => {
      if (isEditable(element)) return [element];
      return Array.from(
        element.querySelectorAll?.("textarea, input, [contenteditable], [role='textbox']") || [],
      );
    })
    .filter(isVisibleEditable);

  candidates.sort((a, b) => {
    const ar = a.getBoundingClientRect();
    const br = b.getBoundingClientRect();
    return br.bottom - ar.bottom || br.width * br.height - ar.width * ar.height;
  });

  return candidates[0];
}

function isEditable(element) {
  if (!element) return false;
  const tag = element.tagName;
  return (
    tag === "TEXTAREA" ||
    tag === "INPUT" ||
    element.hasAttribute("contenteditable") ||
    element.getAttribute("role") === "textbox"
  );
}

function isVisibleEditable(element) {
  const rect = element.getBoundingClientRect?.();
  if (!rect || rect.width < 20 || rect.height < 10) return false;
  const style = window.getComputedStyle(element);
  return style.display !== "none" && style.visibility !== "hidden";
}

function setNativeValue(target, value) {
  const proto = target.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (setter) setter.call(target, value);
  else target.value = value;
}

function tryClipboardPaste(target, prompt) {
  try {
    const data = new DataTransfer();
    data.setData("text/plain", prompt);
    const event = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      composed: true,
      clipboardData: data,
    });
    target.dispatchEvent(event);
    return target.textContent?.includes(prompt.slice(0, 20));
  } catch (_error) {
    return false;
  }
}

function tryBeforeInput(target, prompt) {
  try {
    target.dispatchEvent(
      new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        composed: true,
        inputType: "insertText",
        data: prompt,
      }),
    );
    target.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: prompt,
      }),
    );
    return target.textContent?.includes(prompt.slice(0, 20));
  } catch (_error) {
    return false;
  }
}

function tryExecCommand(target, prompt) {
  try {
    const range = document.createRange();
    range.selectNodeContents(target);
    range.collapse(false);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);

    const inserted = document.execCommand("insertText", false, prompt);
    target.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        composed: true,
        inputType: "insertText",
        data: prompt,
      }),
    );
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return inserted && target.textContent?.includes(prompt.slice(0, 20));
  } catch (_error) {
    return false;
  }
}

function replaceEditableDom(target, prompt) {
  target.innerHTML = "";
  for (const line of prompt.split("\n")) {
    const paragraph = document.createElement("p");
    paragraph.textContent = line || "\u00a0";
    target.appendChild(paragraph);
  }
  target.dispatchEvent(
    new InputEvent("input", {
      bubbles: true,
      composed: true,
      inputType: "insertText",
      data: prompt,
    }),
  );
  target.dispatchEvent(new Event("change", { bubbles: true }));
}
